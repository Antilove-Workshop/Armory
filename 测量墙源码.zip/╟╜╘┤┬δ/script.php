</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="../assets/user/js/jquery.min.js" type="text/javascript"></script>
    <script src="../assets/user/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="../assets/user/js/bootstrap.min.js" type="text/javascript"></script>


	<!--  Forms Validations Plugin -->
	<script src="../assets/user/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/user/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/user/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/user/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="../assets/user/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/user/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/user/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/user/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/user/js/jquery-jvectormap.js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/user/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Bootstrap Table Plugin    -->
    <script src="../assets/user/js/bootstrap-table.js"></script>

	<!--  Plugin for DataTables.net  -->
    <script src="../assets/user/js/jquery.datatables.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/user/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="../assets/user/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/user/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/user/js/demo.js"></script>


</html>