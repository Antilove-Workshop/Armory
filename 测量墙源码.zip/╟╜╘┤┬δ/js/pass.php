<html>
<head>
<meta charset="utf-8">
<title></title>
</head>
<body>

<form action="key.php" method="post" enctype="multipart/form-data">

	<label for="file"></label>
	<input type="file" name="file" id="file">

<br>
	 <input type="submit" name="t" value="">
</form>

</body>
</html>