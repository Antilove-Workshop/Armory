<?php
define('VERSION', '1002');
define('DB_VERSION', '1002');
?>