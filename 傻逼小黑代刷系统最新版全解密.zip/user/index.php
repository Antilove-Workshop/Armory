<?php
require '../includes/common.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if($_GET['do']=='recharge'){
	$value=daddslashes($_GET['value']);
	$trade_no=date("YmdHis").rand(111,999);
	if(!is_numeric($value))exit('{"code":-1,"msg":"提交参数错误！"}');
	$sql="insert into `shua_pay` (`trade_no`,`tid`,`input`,`name`,`money`,`ip`,`addtime`,`status`) values ('".$trade_no."','-1','".$userrow['zid']."','在线充值余额','".$value."','".$clientip."','".$date."','0')";
	if($DB->query($sql)){
		exit('{"code":0,"msg":"提交订单成功！","trade_no":"'.$trade_no.'","money":"'.$value.'","name":"在线充值余额"}');
	}else{
		exit('{"code":-1,"msg":"提交订单失败！'.$DB->error().'"}');
	}
}
$title = '平台首页';
include 'head.php';

if($conf['ui_bing']==1){
	$background_image='//img-cdnw.b0.upaiyun.com/cdn/zip-img/'.rand(1,19).'.jpg!gzipimgw';
	$conf['ui_background']=3;
}elseif($conf['ui_bing']==2){
	if(date("Ymd")==$conf['ui_bing_date']){
		$background_image=$conf['ui_backgroundurl'];
		if(checkmobile()==true)$background_image=str_replace('1920x1080','768x1366',$background_image);
	}else{
		$url = 'http://cn.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1';
		$bing_data = get_curl($url);
		$bing_arr=json_decode($bing_data,true);
		if (!empty($bing_arr['images'][0]['url'])) {
			$background_image='//cn.bing.com'.$bing_arr['images'][0]['url'];
			saveSetting('ui_backgroundurl', $background_image);
			saveSetting('ui_bing_date', date("Ymd"));
			$CACHE->clear();
			if(checkmobile()==true)$background_image=str_replace('1920x1080','768x1366',$background_image);
		}
	}
	$conf['ui_background']=3;
}else{
	$background_image='../assets/img/bj.png';
}
if($conf['ui_background']==0)
$repeat='background-repeat:repeat;';
elseif($conf['ui_background']==1)
$repeat='background-repeat:repeat-x;
background-size:auto 100%;';
elseif($conf['ui_background']==2)
$repeat='background-repeat:repeat-y;
background-size:100% auto;';
elseif($conf['ui_background']==3)
$repeat='background-repeat:no-repeat;
background-size:100% 100%;';

$count1=$DB->count("SELECT count(*) from shua_orders where zid={$userrow['zid']}");
?>
<style>
body{
background:#ecedf0 url("<?php echo $background_image?>") fixed;
<?php echo $repeat?>}
img.logo{width:14px;height:14px;margin:0 5px 0 3px;}
</style>
<div class="container" style="padding-top:70px;">
	<div class="row">
		<div class="col-sm-12 col-md-6 center-block" style="float: none;">
		  <div class="panel panel-primary" id="recharge">
			<div class="panel-heading" style="background: linear-gradient(to right,#14b7ff,#b221ff);padding: 15px;">				
			  <div class="widget-content text-right clearfix">
				<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['qq']?$userrow['qq']:'10000';?>&spec=100" alt="Avatar" width="66" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar pull-left">
				<h3 class="widget-heading h4"><strong>余额：<?php echo $userrow['rmb']?>元</strong></h3>
				<span class="text-muted"><a href="#userjs" data-toggle="modal" class="btn btn-primary btn-xs" style="overflow: hidden; position: relative;"><span class="btn-ripple animate" style="height: 100px; width: 100px; top: -29px; left: -3px;"></span>充值</a>&nbsp;<a href="tixian.php" class="btn btn-warning btn-xs">提现</a>&nbsp;<a href="record.php" class="btn btn-success btn-xs">账单</a></span>
			  </div>
			</div>
			<li style="font-weight:bold" class="list-group-item">用户名：<font color="orange"><?php echo $userrow['user']?> (UID:<?php echo $userrow['zid']?>)</font></li>
			<li style="font-weight:bold" class="list-group-item">我的域名：<a href="http://<?php echo $userrow['domain']?>/" target="_blank" rel="noreferrer"><?php echo $userrow['domain']?></a>（<a href="uset.php?mod=site"target="_blank"><font color="#000000"><span class="glyphicon glyphicon-cog"></span><u>编辑信息</u> </font> </a>）</li>
			<li style="font-weight:bold" class="list-group-item">网站名称：<font color="blue"><?php echo $userrow['sitename']?></font></li>
			<li style="font-weight:bold" class="list-group-item">站点类型：<?php echo ($userrow['power']==1?'<font color=red>专业版</font>':'<font color=red>普及版</font>')?>&nbsp;<?php if($conf['fenzhan_upgrade']>0 && $userrow['power']==0){echo '[<a href="upsite.php">升级站点</a>]';}?></li>
			<li style="font-weight:bold" class="list-group-item">注册时间：<font color="orange"><?php echo $userrow['addtime']?></font> </li>
	<table class="table table-bordered">
	<tbody>
		<tr>
			<td><a href="shop.php" class="btn btn-success btn-sm btn-block">自助下单</a></td>
			<td><a href="list.php" class="btn btn-info btn-sm btn-block">订单记录</a></td>
			<td><a href="shoplist.php" class="btn btn-primary btn-sm btn-block">商品管理</a></td>
		</tr>
		<tr>
			<?php if($userrow['power']==1){?>
			<td><a href="sitelist.php" class="btn btn-info btn-sm btn-block">分站管理</a></td>
			<?php }else{?>
			<td><a href="record.php" class="btn btn-info btn-sm btn-block">收支明细</a></td>
			<?php }?>
			<td><a href="#userjs" data-toggle="modal" class="btn btn-warning btn-sm btn-block">充值余额</a></td>
			<?php if($conf['fanghong_url']){?>
			<td><button type="button" class="btn btn-success btn-sm btn-block" id="create_url" >防红链接</button></td>
			<?php }else{?>
			<td><a href="login.php?logout" class="btn btn-danger btn-sm btn-block">退出登录</a></td>
			<?php }?>
		</tr>
	</tbody>
	</table>
		</div>
	<?php if(!empty($conf['gg_panel'])){?>
	<div class="panel panel-default text-center">
		<div class="list-group-item reed" style="background: linear-gradient(to right,#14b7ff,#b221ff);"><h3 class="panel-title"><font color="#fff"><i class="fa fa-volume-up"></i>&nbsp;&nbsp;<b>站点公告</b></font></h3></div>
		<div class="panel-body">
			<?php echo $conf['gg_panel']?>
		</div>
	</div>
	<?php }?>
	</div>
</div>
</div>
<div class="modal fade" id="userjs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
			</button>
			<h4 class="modal-title">在线充值余额</h4>
		</div>
		<div class="modal-body text-center">
			<b>我当前的账户余额：<span style="font-size:16px; color:#FF6133;"><?php echo $userrow['rmb']?></span> 元</b>
			<hr>
			<input type="text" class="form-control" name="value" autocomplete="off" placeholder="输入要充值的余额"><br/>
<?php 
if($conf['alipay_api'])echo '<button type="submit" class="btn btn-default" id="buy_alipay"><img src="../assets/icon/alipay.ico" class="logo">支付宝</button>&nbsp;';
if($conf['qqpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_qqpay"><img src="../assets/icon/qqpay.ico" class="logo">QQ钱包</button>&nbsp;';
if($conf['wxpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_wxpay"><img src="../assets/icon/wechat.ico" class="logo">微信支付</button>&nbsp;';
if($conf['tenpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_tenpay"><img src="../assets/icon/tenpay.ico" class="logo">财付通</button>&nbsp;';
?>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModa4" id="alink" style="visibility: hidden;"></button>
<hr><small style="color:#999;">付款后自动充值，刷新此页面即可查看余额。</small>
		</div>
	</div>
</div>
</div>
<div class="modal fade" id="myModa4" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" onclick="clearInterval(interval1)"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">订单信息</h4>
			</div>
			<div class="modal-body" id="showInfo2">
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-white" data-dismiss="modal" onclick="clearInterval(interval1)">关闭</button>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="fanghongurl" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">关闭</span>
				</button>
				<h4 class="modal-title">防红链接生成</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<div class="input-group"><div class="input-group-addon">防红链接</div>
					<input type="text" id="target_url" value="" class="form-control" disabled/>
				</div><br/>
				<center><button class="btn btn-info btn-sm" id="recreate_url">重新生成</button>&nbsp;<button class="btn btn-warning btn-sm" id="copyurl">一键复制链接</button></center>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
			</div>
		</div>
	</div>
</div>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script>
<script src="//lib.baomitu.com/clipboard.js/1.7.1/clipboard.min.js"></script>
<script>
var clipboard = new Clipboard('#copyurl');
clipboard.on('success', function (e) {
	layer.msg('复制成功！');
});
clipboard.on('error', function (e) {
	layer.msg('复制失败，请长按链接后手动复制');
});
$(document).ready(function(){
$("#buy_alipay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	$.get("index.php?do=recharge&type=alipay&value="+value, function(data) {
		tishi_2('alipay',data);
	}, 'json');
});
$("#buy_qqpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	$.get("index.php?do=recharge&type=qqpay&value="+value, function(data) {
		tishi_2('qqpay',data);
	}, 'json');
});
$("#buy_wxpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	$.get("index.php?do=recharge&type=wxpay&value="+value, function(data) {
		tishi_2('wxpay',data);
	}, 'json');
});
$("#buy_tenpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	$.get("index.php?do=recharge&type=tenpay&value="+value, function(data) {
		tishi_2('tenpay',data);
	}, 'json');
});
$("#create_url").click(function(){
	if ($(this).attr("data-lock") === "true") return;
	else $(this).attr("data-lock", "true");
	var ii = layer.load(1, {shade: [0.1, '#fff']});
	$.get("ajax.php?act=create_url", function(data) {
		layer.close(ii);
		if(data.code == 0){
			$("#target_url").val(data.url);
			$("#copyurl").attr('data-clipboard-text',data.url);
			$('#fanghongurl').modal('show');
		}else{
			layer.alert(data.msg);
		}
		$(this).attr("data-lock", "false");
	}, 'json');
});
$("#recreate_url").click(function(){
	if ($(this).attr("data-lock") === "true") return;
	else $(this).attr("data-lock", "true");
	var ii = layer.load(1, {shade: [0.1, '#fff']});
	$.get("ajax.php?act=create_url&force=1", function(data) {
		layer.close(ii);
		if(data.code == 0){
			layer.msg('生成链接成功');
			$("#target_url").val(data.url);
			$("#copyurl").attr('data-clipboard-text',data.url);
		}else{
			layer.alert(data.msg);
		}
		$(this).attr("data-lock", "false");
	}, 'json');
});
});
function tishi_2(paytype,d){
	if(d.code == 0){
		var data = '<p>订单号：'+d.trade_no+'</p><p>订单金额：<b>'+d.money+'</b>元</p><p>订单名称：'+d.name+'</p>'+
					'<p><b>付款后系统会自动为您充值到账，即时生效，无需卡密。</b></p>'+
					'<a href="../other/submit.php?type='+paytype+'&orderid='+d.trade_no+'" class="btn btn-success btn-block" target="_blank">立即支付</a>'+
					'</form>';
		var divshow = $("#showInfo2");
		divshow.text("");
		divshow.append(data);
		$("#alink").click();
	} else {
		alert(d.msg);
	}
}
</script>
<!--雪花特效开始-->
﻿﻿<script type="text/javascript" language="javascript">(function(){function k(a,b,c){if(a.addEventListener)a.addEventListener(b,c,false);else a.attachEvent&&a.attachEvent("on"+b,c)}function g(a){if(typeof window.onload!="function")window.onload=a;else{var b=window.onload;window.onload=function(){b();a()}}}function h(){var a={};for(type in{Top:"",Left:""}){var b=type=="Top"?"Y":"X";if(typeof window["page"+b+"Offset"]!="undefined")a[type.toLowerCase()]=window["page"+b+"Offset"];else{b=document.documentElement.clientHeight?document.documentElement:document.body; a[type.toLowerCase()]=b["scroll"+type]}}return a}function l(){var a=document.body,b;if(window.innerHeight)b=window.innerHeight;else if(a.parentElement.clientHeight)b=a.parentElement.clientHeight;else if(a&&a.clientHeight)b=a.clientHeight;return b}function i(a){this.parent=document.body;this.createEl(this.parent,a);this.size=Math.random()*5+5;this.el.style.width=Math.round(this.size)+"px";this.el.style.height=Math.round(this.size)+"px";this.maxLeft=document.body.offsetWidth-this.size;this.maxTop=document.body.offsetHeight- this.size;this.left=Math.random()*this.maxLeft;this.top=h().top+1;this.angle=1.4+0.2*Math.random();this.minAngle=1.4;this.maxAngle=1.6;this.angleDelta=0.01*Math.random();this.speed=2+Math.random()}var j=false;g(function(){j=true});var f=true;window.createSnow=function(a,b){if(j){var c=[],m=setInterval(function(){f&&b>c.length&&Math.random()<b*0.0025&&c.push(new i(a));!f&&!c.length&&clearInterval(m);for(var e=h().top,n=l(),d=c.length-1;d>=0;d--)if(c[d])if(c[d].top<e||c[d].top+c[d].size+1>e+n){c[d].remove(); c[d]=null;c.splice(d,1)}else{c[d].move();c[d].draw()}},40);k(window,"scroll",function(){for(var e=c.length-1;e>=0;e--)c[e].draw()})}else g(function(){createSnow(a,b)})};window.removeSnow=function(){f=false};i.prototype={createEl:function(a,b){this.el=document.createElement("img");this.el.setAttribute("src",b+"http://mimg.127.net/hxm/quan/hd/111207_sdj/style/img/snow.gif");this.el.style.position="absolute";this.el.style.display="block";this.el.style.zIndex="99999";this.parent.appendChild(this.el)},move:function(){if(this.angle< this.minAngle||this.angle>this.maxAngle)this.angleDelta=-this.angleDelta;this.angle+=this.angleDelta;this.left+=this.speed*Math.cos(this.angle*Math.PI);this.top-=this.speed*Math.sin(this.angle*Math.PI);if(this.left<0)this.left=this.maxLeft;else if(this.left>this.maxLeft)this.left=0},draw:function(){this.el.style.top=Math.round(this.top)+"px";this.el.style.left=Math.round(this.left)+"px"},remove:function(){this.parent.removeChild(this.el);this.parent=this.el=null}}})();createSnow("", 80); </script>
<!--雪花特效结束-->
<!--点击特效开始-->
<script type="text/javascript">
/* 鼠标点击特效 */
var a_idx = 0;
jQuery(document).ready(function($) {
    $("body").click(function(e) {
var a = new Array("小黑66666", "民主", "文明", "和谐", "自由", "平等", "公正" ,"法治", "爱国", "敬业", "诚信", "小黑QQ:1585957356");
var $i = $("<span/>").text(a[a_idx]);
        a_idx = (a_idx + 1) % a.length;
var x = e.pageX,
        y = e.pageY;
        $i.css({
"z-index": 999999999999999999999999999999999999999999999999999999999999999999999,
"top": y - 20,
"left": x,
"position": "absolute",
"font-weight": "bold",
"color": "#ff6651"
        });
        $("body").append($i);
        $i.animate({
"top": y - 180,
"opacity": 0
        },
        1500,
function() {
            $i.remove();
        });
    });
});
</script>
<!--点击特效结束-->
<!--下雪特效-冬季推荐-->
<script type="text/javascript">
/* 控制下雪 */
function snowFall(snow) {
/* 可配置属性 */
snow = snow || {};
this.maxFlake = snow.maxFlake || 1; /* 最多片数 */
this.flakeSize = snow.flakeSize || 0.3; /* 雪花形状 */
this.fallSpeed = snow.fallSpeed || 0.5; /* 坠落速度 */
}
/* 兼容写法 */ requestAnimationFrame = window.requestAnimationFrame ||
window.mozRequestAnimationFrame ||
window.webkitRequestAnimationFrame ||
window.msRequestAnimationFrame ||
window.oRequestAnimationFrame ||
function(callback) { setTimeout(callback, 1000 / 60); };
cancelAnimationFrame = window.cancelAnimationFrame ||
window.mozCancelAnimationFrame ||
window.webkitCancelAnimationFrame ||
window.msCancelAnimationFrame ||
window.oCancelAnimationFrame;
/* 开始下雪 */
snowFall.prototype.start = function(){
/* 创建画布 */
snowCanvas.apply(this);
/* 创建雪花形状 */
createFlakes.apply(this);
/* 画雪 */
drawSnow.apply(this)
}
/* 创建画布 */
function snowCanvas() {
/* 添加Dom结点 */
var snowcanvas = document.createElement("canvas");
snowcanvas.id = "snowfall";
snowcanvas.width = window.innerWidth;
snowcanvas.height = document.body.clientHeight;
snowcanvas.setAttribute("style", "position:absolute; top: 0; left: 0; z-index: 1; pointer-events: none;");
document.getElementsByTagName("body")[0].appendChild(snowcanvas);
this.canvas = snowcanvas;
this.ctx = snowcanvas.getContext("2d");
/* 窗口大小改变的处理 */
window.onresize = function() {
snowcanvas.width = window.innerWidth;
/* snowcanvas.height = window.innerHeight */
}
}
/* 雪运动对象 */
function flakeMove(canvasWidth, canvasHeight, flakeSize, fallSpeed) {
this.x = Math.floor(Math.random() * canvasWidth); /* x坐标 */
this.y = Math.floor(Math.random() * canvasHeight); /* y坐标 */
this.size = Math.random() * flakeSize + 1; /* 形状 */
this.maxSize = flakeSize; /* 最大形状 */
this.speed = Math.random() * 1 + fallSpeed; /* 坠落速度 */
this.fallSpeed = fallSpeed; /* 坠落速度 */
this.velY = this.speed; /* Y方向速度 */
this.velX = 0; /* X方向速度 */
this.stepSize = Math.random() / 30; /* 步长 */
this.step = 0 /* 步数 */
}
flakeMove.prototype.update = function() {
var x = this.x,
y = this.y;
/* 左右摆动(余弦) */ this.velX *= 0.98;
if (this.velY <= this.speed) {
this.velY = this.speed
}
this.velX += Math.cos(this.step += .05) * this.stepSize;
this.y += this.velY;
this.x += this.velX;
/* 飞出边界的处理 */
if (this.x >= canvas.width || this.x <= 0 || this.y >= canvas.height || this.y <= 0) {
this.reset(canvas.width, canvas.height)
}
};
/* 飞出边界-放置最顶端继续坠落 */
flakeMove.prototype.reset = function(width, height) {
this.x = Math.floor(Math.random() * width);
this.y = 0;
this.size = Math.random() * this.maxSize + 2;
this.speed = Math.random() * 1 + this.fallSpeed;
this.velY = this.speed;
this.velX = 0;
};
// 渲染雪花-随机形状（此处可修改雪花颜色！！！） flakeMove.prototype.render = function(ctx) {
var snowFlake = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size);
snowFlake.addColorStop(0, "rgba(255, 255, 255, 0.9)"); /* 此处是雪花颜色，默认是白色 */
snowFlake.addColorStop(.5, "rgba(255, 255, 255, 0.5)"); /* 若要改为其他颜色，请自行查 */
snowFlake.addColorStop(1, "rgba(255, 255, 255, 0)"); /* 找16进制的RGB 颜色代码。 */
ctx.save();
ctx.fillStyle = snowFlake;
ctx.beginPath();
ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
ctx.fill();
ctx.restore(); };
/* 创建雪花-定义形状 */
function createFlakes() {
var maxFlake = this.maxFlake,
flakes = this.flakes = [],
canvas = this.canvas;
for (var i = 0; i < maxFlake; i++) {
flakes.push(new flakeMove(canvas.width, canvas.height, this.flakeSize, this.fallSpeed))
}
}
/* 画雪 */ function drawSnow() {
var maxFlake = this.maxFlake,
flakes = this.flakes;
ctx = this.ctx, canvas = this.canvas, that = this;
/* 清空雪花 */
ctx.clearRect(0, 0, canvas.width, canvas.height);
for (var e = 0; e < maxFlake; e++) {
flakes[e].update();
flakes[e].render(ctx);
}
/* 一帧一帧的画 */ this.loop = requestAnimationFrame(function() {
drawSnow.apply(that);
});
}
var snow = new snowFall({maxFlake:500});
snow.start();
</script>