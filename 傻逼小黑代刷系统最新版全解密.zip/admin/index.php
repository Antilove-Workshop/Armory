<?php
/*
盗版死全家，小黑QQ:1585957356
*/
include("../includes/common.php");
$title='小黑代刷系统';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>  
<br><br>
<div class="container" style="padding-top:5px;">
 <div class="panel panel-danger" style="border: 1px solid #42a5f5;">
             <div class="panel-heading" style='background:linear-gradient(to right,#14b7ff,#66ccff,#9966ff);'>
	<div class="col-lg-8 col-md-12 col-lg-offset-2 text-center">
<div class="panel panel-info">
             </div>
    <div class="panel panel-danger" style="border: 1px solid #42a5f5;">
        <div class="panel-heading" style="background-color: #42a5f5;border: 1px solid #42a5f5;"><h3 class="panel-title" ><font color="#FF00FF">快</font><font color="#BF00FF">速</font><font color="#8000FF">导</font><font color="#8000FF">航</font></h3></div>
<img src="./xiaoci.png" width="100%" height="100%" >
<li class="list-group-item"><center>
                         <div class="panel-heading" style='background:linear-gradient(to right,#14b7ff,#66ccff,#9966ff);'>
                <a href="classlist.php" style="background-color: red;color:white;" class="btn btn-xs ">分类列表</a>&nbsp;
               <a href="shoplist.php" style="background-color: red;color:white;" class="btn btn-xs ">商品列表</a>&nbsp;
           <a href="list.php" style="background-color: red;color:white;" class="btn btn-xs ">订单列表</a>&nbsp;    
          <a href="./clone.php" style="background-color: red;color:white;" class="btn btn-xs ">商品克隆</a>&nbsp;    
            </li>
  <li class="list-group-item"><center>
               <div class="panel-heading" style='background:linear-gradient(to right,#14b7ff,#66ccff,#9966ff);'>
                  <a href="./set.php?mod=gonggao"style="background-color: orange;color:white;" class="btn btn-xs ">网站公告</a>&nbsp;
                <a href="./shequlist.php" style="background-color: orange;color:white;" class="btn btn-xs ">社区对接</a>&nbsp;
               <a href="./sitelist.php" style="background-color: orange;color:white;" class="btn btn-xs ">分站列表</a>&nbsp;
           <a href="./set.php?mod=fenzhan" style="background-color: orange;color:white;" class="btn btn-xs ">分站配置</a>&nbsp;    
            </li>
            <li class="list-group-item"><center>
                         <div class="panel-heading" style='background:linear-gradient(to right,#14b7ff,#66ccff,#9966ff);'>
            <a href="./set.php?mod=template" style="background-color: green;color:white;" class="btn btn-xs ">首页模板</a>&nbsp;
                <a href="./set.php?mod=upimg" style="background-color: green;color:white;" class="btn btn-xs ">首页logo</a>&nbsp;
             <a href="./set.php?mod=site" style="background-color: green;color:white;" class="btn btn-xs ">网站信息</a>&nbsp;
             <a href="./set.php?mod=pay" style="background-color: green;color:white;" class="btn btn-xs ">支付设置</a>&nbsp;
            </li>
            <li class="list-group-item"><center>
                         <div class="panel-heading" style='background:linear-gradient(to right,#14b7ff,#66ccff,#9966ff);'>
                   <a href="./shequlist.php" style="background-color: blue;color:white;" class="btn btn-xs ">社区对接</a>&nbsp;
                   <a href="./update.php" style="background-color: blue;color:white;" class="btn btn-xs ">检测更新</a>&nbsp;
                   <a href="https://jq.qq.com/?_wv=1027&k=5XeQmTV" style="background-color: blue;color:white;" class="btn btn-xs ">官方Q群</a>&nbsp;
                   <a href="http://wpa.qq.com/msgrd?v=3&uin=1585957356&site=qq&menu=yes" style="background-color: blue;color:white;" class="btn btn-xs ">程序作者</a>&nbsp;
            </li>
            
          	</div>
<table class="table table-bordered">
<tbody>
	</ul>
<tr height="25">
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-time"></i>运营天数</b></br><span id="yxts"></span>天</font></td>
<td align="center"><font color="#1700EA"><b><span class="glyphicon glyphicon-tint"></span>今日订单数</b></br><span id="count4"></span>条</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-usd"></i>今日交易额</b></br></span><span id="count5"></span>元</font></td>
</tr>
<tr height="25">
<td align="center"><font color="#1700EA"><b><span class="glyphicon glyphicon-tint"></span>订单总数</b></br><span id="count1"></span>条</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-check"></i>已处理订单</b></br></span><span id="count2"></span>条</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-exclamation-sign"></i>待处理订单</b></span></br><span id="count3"></span>条</font></td>
</tr>
<tr height="25">
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-globe"></i>分站总数</b></span></br><span id="count6"></span>个</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-globe"></i>今日新开分站</b></br></span><span id="count7"></span>个</font></td>
<td align="center"><font color="#1700EA"><b><span class="glyphicon glyphicon-check"></span>今日分站提成</b></br><span id="count8"></span>元</font></td>
</tr>
<tr height="25">
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-usd"></i>分站总提成</b></br><span id="count9"></span>元</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-gbp"></i>分站总资金</b></span></br><span id="count10"></span>元</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-usd"></i>待处理提现</b></br></span><span id="count11"></span>元</font></td>
</tr>
<tr height="25">
<td align="center"><font color="#1700EA"><b><span class="glyphicon glyphicon-check"></span>QQ钱包交易额</b></br><span id="count12"></span>元</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-check"></i>微信交易额</b></br></span><span id="count13"></span>元</font></td>
<td align="center"><font color="#1700EA"><b><i class="glyphicon glyphicon-check"></i>支付宝交易额</b></span></br><span id="count14"></span>元</font></td>
</tr>
<tr height="25">
<td align="center" colspan="3"><a href="../" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-home"></i>网站首页</a>&nbsp;<a href="./login.php?logout" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-log-out"></i>退出登录</a></td>
</tr>
       <div class="panel panel-danger" style="border: 1px solid #42a5f5;">
        <div class="panel-heading" style="background-color: #42a5f5;border: 1px solid #42a5f5;"><h3 class="panel-title" ><font color="#FF00FF">程</font><font color="#BF00FF">序</font><font color="#8000FF">信</font><font color="#8000FF">息</font></h3></div>
	<ul class="list-group">
		<li class="list-group-item">
			<b><font color="#00FFFF">当</font><font color="#24DBFF">前</font><font color="#48B7FF">版</font><font color="#6C93FF">本</font><font color="#C027FF">：</font></b><font color="#FF00FF">小</font><font color="#F00FF0">黑</font><font color="#E11EE1">代</font><font color="#D22DD2">刷</font><font color="#C33CC3">系</font><font color="#B44BB4">统</font><font color="#A55AA5">V</font><font color="#A06996">5</font><font color="#A07887">.</font><font color="#A08778">0</font><font color="#A0E11E"> </font>
		</li>
		<li class="list-group-item">
			<b><font color="#00FFFF">维</font><font color="#24DBFF">护</font><font color="#48B7FF">更</font><font color="#6C93FF">新</font><font color="#C027FF">：</font></b>    <a href="http://wpa.qq.com/msgrd?v=3&uin=1585957356&site=qq&menu=yes" class="btn btn-xs btn-info">联系小黑</a>
		</li>
     <li class="list-group-item">
			<b><font color="#00FFFF">维</font><font color="#24DBFF">护</font><font color="#48B7FF">更</font><font color="#6C93FF">新</font><font color="#906FFF">人</font><font color="#B44BFF">员</font><font color="#C027FF">：</font></b><font color="#FF00FF">小</font><font color="#F00FF0">黑</font><font color="#E11EE1">Q</font><font color="#D22DD2">Q</font><font color="#C33CC3">:</font><font color="#B44BB4"> </font><font color="#A55AA5">1</font><font color="#A06996">5</font><font color="#A07887">8</font><font color="#A08778">5</font><font color="#A09669">9</font><font color="#A0A55A">5</font><font color="#A0B44B">7</font><font color="#A0C33C">3</font><font color="#A0D22D">5</font><font color="#A0E11E">6</font><font color="#A0E11E"> </font>
		</li>
	</ul>
<?php
foreach($sec_msg as $row){
	echo $row;
}
if(count($sec_msg)==0)echo '<li class="list-group-item"><span class="btn btn-xs btn-info">安全</span>&nbsp;暂未发现网站安全问题</li>';
?>
	</ul>
</div>
    </div>
  </div>
<script>
$(document).ready(function(){
	$('#title').html('正在加载数据中...');
	$.ajax({
		type : "GET",
		url : "ajax.php?act=getcount",
		dataType : 'json',
		async: true,
		success : function(data) {
			$('#title').html('数据中心');
			$('#yxts').html(data.yxts);
			$('#count1').html(data.count1);
			$('#count2').html(data.count2);
			$('#count3').html(data.count3);
			$('#count4').html(data.count4);
			$('#count5').html(data.count5);
			$('#count6').html(data.count6);
			$('#count7').html(data.count7);
			$('#count8').html(data.count8);
			$('#count9').html(data.count9);
			$('#count10').html(data.count10);
			$('#count11').html(data.count11);
			$('#count12').html(data.count12);
			$('#count13').html(data.count13);
			$('#count14').html(data.count14);
		}
	});
})
</script>
﻿﻿<script type="text/javascript" language="javascript">(function(){function k(a,b,c){if(a.addEventListener)a.addEventListener(b,c,false);else a.attachEvent&&a.attachEvent("on"+b,c)}function g(a){if(typeof window.onload!="function")window.onload=a;else{var b=window.onload;window.onload=function(){b();a()}}}function h(){var a={};for(type in{Top:"",Left:""}){var b=type=="Top"?"Y":"X";if(typeof window["page"+b+"Offset"]!="undefined")a[type.toLowerCase()]=window["page"+b+"Offset"];else{b=document.documentElement.clientHeight?document.documentElement:document.body; a[type.toLowerCase()]=b["scroll"+type]}}return a}function l(){var a=document.body,b;if(window.innerHeight)b=window.innerHeight;else if(a.parentElement.clientHeight)b=a.parentElement.clientHeight;else if(a&&a.clientHeight)b=a.clientHeight;return b}function i(a){this.parent=document.body;this.createEl(this.parent,a);this.size=Math.random()*5+5;this.el.style.width=Math.round(this.size)+"px";this.el.style.height=Math.round(this.size)+"px";this.maxLeft=document.body.offsetWidth-this.size;this.maxTop=document.body.offsetHeight- this.size;this.left=Math.random()*this.maxLeft;this.top=h().top+1;this.angle=1.4+0.2*Math.random();this.minAngle=1.4;this.maxAngle=1.6;this.angleDelta=0.01*Math.random();this.speed=2+Math.random()}var j=false;g(function(){j=true});var f=true;window.createSnow=function(a,b){if(j){var c=[],m=setInterval(function(){f&&b>c.length&&Math.random()<b*0.0025&&c.push(new i(a));!f&&!c.length&&clearInterval(m);for(var e=h().top,n=l(),d=c.length-1;d>=0;d--)if(c[d])if(c[d].top<e||c[d].top+c[d].size+1>e+n){c[d].remove(); c[d]=null;c.splice(d,1)}else{c[d].move();c[d].draw()}},40);k(window,"scroll",function(){for(var e=c.length-1;e>=0;e--)c[e].draw()})}else g(function(){createSnow(a,b)})};window.removeSnow=function(){f=false};i.prototype={createEl:function(a,b){this.el=document.createElement("img");this.el.setAttribute("src",b+"http://mimg.127.net/hxm/quan/hd/111207_sdj/style/img/snow.gif");this.el.style.position="absolute";this.el.style.display="block";this.el.style.zIndex="99999";this.parent.appendChild(this.el)},move:function(){if(this.angle< this.minAngle||this.angle>this.maxAngle)this.angleDelta=-this.angleDelta;this.angle+=this.angleDelta;this.left+=this.speed*Math.cos(this.angle*Math.PI);this.top-=this.speed*Math.sin(this.angle*Math.PI);if(this.left<0)this.left=this.maxLeft;else if(this.left>this.maxLeft)this.left=0},draw:function(){this.el.style.top=Math.round(this.top)+"px";this.el.style.left=Math.round(this.left)+"px"},remove:function(){this.parent.removeChild(this.el);this.parent=this.el=null}}})();createSnow("", 80); </script>
<script type="text/javascript">
var a_idx = 0;
jQuery(document).ready(function($) {
    $("body").click(function(e) {
var a = new Array("小黑66666", "小黑代刷系统", "小黑QQ:1585957356");
var $i = $("<span/>").text(a[a_idx]);
        a_idx = (a_idx + 1) % a.length;
var x = e.pageX,
        y = e.pageY;
        $i.css({
"z-index": 999999999999999999999999999999999999999999999999999999999999999999999,
"top": y - 20,
"left": x,
"position": "absolute",
"font-weight": "bold",
"color": "#ff6651"
        });
        $("body").append($i);
        $i.animate({
"top": y - 180,
"opacity": 0
        },
        1500,
function() {
            $i.remove();
        });
    });
});
</script>
<script type="text/javascript">
/* 控制下雪 */
function snowFall(snow) {
/* 可配置属性 */
snow = snow || {};
this.maxFlake = snow.maxFlake || 3; /* 最多片数 */
this.flakeSize = snow.flakeSize || 0.3; /* 雪花形状 */
this.fallSpeed = snow.fallSpeed || 0.3; /* 坠落速度 */
}
/* 兼容写法 */ requestAnimationFrame = window.requestAnimationFrame ||
window.mozRequestAnimationFrame ||
window.webkitRequestAnimationFrame ||
window.msRequestAnimationFrame ||
window.oRequestAnimationFrame ||
function(callback) { setTimeout(callback, 1000 / 60); };
cancelAnimationFrame = window.cancelAnimationFrame ||
window.mozCancelAnimationFrame ||
window.webkitCancelAnimationFrame ||
window.msCancelAnimationFrame ||
window.oCancelAnimationFrame;
/* 开始下雪 */
snowFall.prototype.start = function(){
/* 创建画布 */
snowCanvas.apply(this);
/* 创建雪花形状 */
createFlakes.apply(this);
/* 画雪 */
drawSnow.apply(this)
}
/* 创建画布 */
function snowCanvas() {
/* 添加Dom结点 */
var snowcanvas = document.createElement("canvas");
snowcanvas.id = "snowfall";
snowcanvas.width = window.innerWidth;
snowcanvas.height = document.body.clientHeight;
snowcanvas.setAttribute("style", "position:absolute; top: 0; left: 0; z-index: 1; pointer-events: none;");
document.getElementsByTagName("body")[0].appendChild(snowcanvas);
this.canvas = snowcanvas;
this.ctx = snowcanvas.getContext("2d");
/* 窗口大小改变的处理 */
window.onresize = function() {
snowcanvas.width = window.innerWidth;
/* snowcanvas.height = window.innerHeight */
}
}
/* 雪运动对象 */
function flakeMove(canvasWidth, canvasHeight, flakeSize, fallSpeed) {
this.x = Math.floor(Math.random() * canvasWidth); /* x坐标 */
this.y = Math.floor(Math.random() * canvasHeight); /* y坐标 */
this.size = Math.random() * flakeSize + 1; /* 形状 */
this.maxSize = flakeSize; /* 最大形状 */
this.speed = Math.random() * 1 + fallSpeed; /* 坠落速度 */
this.fallSpeed = fallSpeed; /* 坠落速度 */
this.velY = this.speed; /* Y方向速度 */
this.velX = 0; /* X方向速度 */
this.stepSize = Math.random() / 30; /* 步长 */
this.step = 0 /* 步数 */
}
flakeMove.prototype.update = function() {
var x = this.x,
y = this.y;
/* 左右摆动(余弦) */ this.velX *= 0.98;
if (this.velY <= this.speed) {
this.velY = this.speed
}
this.velX += Math.cos(this.step += .05) * this.stepSize;
this.y += this.velY;
this.x += this.velX;
/* 飞出边界的处理 */
if (this.x >= canvas.width || this.x <= 0 || this.y >= canvas.height || this.y <= 0) {
this.reset(canvas.width, canvas.height)
}
};
/* 飞出边界-放置最顶端继续坠落 */
flakeMove.prototype.reset = function(width, height) {
this.x = Math.floor(Math.random() * width);
this.y = 0;
this.size = Math.random() * this.maxSize + 2;
this.speed = Math.random() * 1 + this.fallSpeed;
this.velY = this.speed;
this.velX = 0;
};
// 渲染雪花-随机形状（此处可修改雪花颜色！！！） flakeMove.prototype.render = function(ctx) {
var snowFlake = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size);
snowFlake.addColorStop(0, "rgba(255, 255, 255, 0.9)"); /* 此处是雪花颜色，默认是白色 */
snowFlake.addColorStop(.5, "rgba(255, 255, 255, 0.5)"); /* 若要改为其他颜色，请自行查 */
snowFlake.addColorStop(1, "rgba(255, 255, 255, 0)"); /* 找16进制的RGB 颜色代码。 */
ctx.save();
ctx.fillStyle = snowFlake;
ctx.beginPath();
ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
ctx.fill();
ctx.restore(); };
/* 创建雪花-定义形状 */
function createFlakes() {
var maxFlake = this.maxFlake,
flakes = this.flakes = [],
canvas = this.canvas;
for (var i = 0; i < maxFlake; i++) {
flakes.push(new flakeMove(canvas.width, canvas.height, this.flakeSize, this.fallSpeed))
}
}
/* 画雪 */ function drawSnow() {
var maxFlake = this.maxFlake,
flakes = this.flakes;
ctx = this.ctx, canvas = this.canvas, that = this;
/* 清空雪花 */
ctx.clearRect(0, 0, canvas.width, canvas.height);
for (var e = 0; e < maxFlake; e++) {
flakes[e].update();
flakes[e].render(ctx);
}
/* 一帧一帧的画 */ this.loop = requestAnimationFrame(function() {
drawSnow.apply(that);
});
}
var snow = new snowFall({maxFlake:500});
snow.start();
</script>
