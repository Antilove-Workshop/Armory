<?php
/**
 * 自助下单系统
**/
include("../includes/common.php");
$title='网站前台配置';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
	$mod=isset($_GET['mod'])?$_GET['mod']:null;
	if($mod=='gonggao_n'){
	$zbuisd=$_POST['zbuis'];
	$fhdbs=$_POST['fhdb'];
	$xzkdxs=$_POST['xzkdx'];
	saveSetting('zbuis',$zbuisd);
	saveSetting('fhdb',$fhdbs);
	saveSetting('xzkdx',$xzkdxs);
	$ad=$CACHE->clear();
	if($ad)showmsg('修改成功！',1);
	else showmsg('修改失败！<br/>'.$DB->error(),4);}
?>
<div class="panel panel-primary">
<div class="panel-heading" style="background: linear-gradient(to right,#14b7ff,#5ccdde,#b221ff);"><h3 class="panel-title">网站前台配置</h3></div>
<div class="panel-body">
  <form action="./youyun.php?mod=gonggao_n" method="post" class="form-horizontal" role="form">
	<div class="form-group">
	  <label class="col-sm-2 control-label">首页更多设置</label>
	  <div class="col-sm-10"><textarea class="form-control" name="zbuis" rows="6"><?php echo htmlspecialchars($conf['zbuis']);?></textarea></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">开启返回顶部</label>
	  <div class="col-sm-10"><select class="form-control" name="fhdb" default="1"><?php
if($conf['fhdb']==1){
	echo '<option value="1">开启</option><option value="0">关闭</option>';
}else{
	echo '<option value="0">关闭</option><option value="1">开启</option>'; //其实可以不用写
}
?></select></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">选择框大小</label>
	  <div class="col-sm-10"><select class="form-control" name="xzkdx" default="1"><?php
if($conf['xzkdx']==20){
	echo '<option value="20">20%</option><option value="25">25%</option>';
}else{
	echo '<option value="25">25%</option><option value="20">20%</option>'; //其实可以不用写
}
?></select></div>
	</div><br/>
	<div class="form-group">
	  <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/><br/>
	 </div>
	</div>
  </form>
</div>
</div>
</div>
</div>
</div>