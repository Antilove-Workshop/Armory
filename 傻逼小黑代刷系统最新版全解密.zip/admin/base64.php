<?php


$title='小黑云加密';
include './head.php';
function phpencode($code) {
$code = str_replace(array('<?php','?>','<?PHP'),array('','',''),$code);
$encode = base64_encode(gzdeflate($code));
$encode = '<?php
*/'."\neval(gzinflate(base64_decode("."'".$encode."'".")));\n?>";
return $encode;
}
?>
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary" style="margin:1% 1% 1% 1%;background: rgba(255, 251, 251, 0.7)">
                <div class="panel-heading bk-bg-primary">
                    <h6><span class="panel-title">PHP文件在线加密</span></h6>
                </div>
                <div class="panel-body">
				<form method='post'>
  <div class="form-group">
    <label>输入你要加密的代码</label>
    <textarea class="form-control" rows="5" name="source"></textarea>
  </div>
      <input class="btn btn-primary btn-block bk-margin-top-10" type="submit" name="btn" value="点击加密"></form>
   <div class="form-group">
    <label>加密后的代码</label>
    <textarea class="form-control" rows="5"><?php
if(!empty($_POST['source'])) {
echo  htmlspecialchars(phpencode(stripcslashes($_POST['source'])));
}
?>
</textarea>
  </div>
<?php
if($_POST['source']==NULL){}else{
echo '<div class="alert alert-success" role="alert"><span class="glyphicon glyphicon-info-sign"></span> <strong>提示</strong>：加密成功！</div>';
}
?>
<div class="alert alert-info" role="alert"><span class="glyphicon glyphicon-info-sign"></span> <strong>提示</strong>:输入要加密的PHP代码后点击按钮即可加密。</div>
</body>
</html>
