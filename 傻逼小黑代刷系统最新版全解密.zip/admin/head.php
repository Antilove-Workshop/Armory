<?php
include '../ayangw/common.php';
@header('Content-Type: text/html; charset=UTF-8');
if($islogin==1){
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>小黑QQ:1585957356</title>
  <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  
<link rel="stylesheet" href="https://template.down.swap.wang/ui/angulr_2.0.1/html/css/app.css" type="text/css" />
  
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="//cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
  <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--[if lt IE 9]>
    <script src="//cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="js/jquery.cookie.js"></script>
  <script src="js/jquery.md5.js"></script>

  <script src="../layer/layer.js"></script>
    <script src="js/ayangw.js"></script>
  
</head>
<body>

  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only"><font color="#00FFFF">导</font><font color="#40BFFF">航</font><font color="#807FFF">按</font><font color="#C03FFF">键</font></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./" style="color:#42a5f5;"><font color="#00FFFF">小</font><font color="#2AD5FF">黑</font><font color="#54ABFF">代</font><font color="#7E81FF">刷</font><font color="#A857FF">系</font><font color="#D22DFF">统</font></a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right" >
          <li class="">
            <a href="./" style="color:#18a0a0;"><span class="glyphicon glyphicon-user"></span><font color="#0000FF">平</font><font color="#4000FF">台</font><font color="#8000FF">首</font><font color="#C000FF">页</font></a>
          </li>
		  <li class="">
            <a href="./list.php" style="color:#0000ff;"><span class="glyphicon glyphicon-calendar"></span> <font color="#8000FF">订</font><font color="#4040FF">单</font><font color="#0080FF">管</font><font color="#00C0FF">理</font></a>
          </li>
          <li class="">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:#f48224;"><span  class="glyphicon glyphicon-list-alt"></span> <font color="#8000FF">商</font><font color="#4040FF">品</font><font color="#0080FF">管</font><font color="#00C0FF">理</font><b class="caret"></b></a>
            <ul class="dropdown-menu">
             <li class="">
                 <a href="./classlist.php" style="color:red"><span class="glyphicon glyphicon-list"></span> <font color="#FF60FF">目</font><font color="#BFA0BF">录</font><font color="#7FE07F">列</font><font color="#3FFF3F">表</font></a>
             </li>
			  <li class="">
                 <a href="shoplist.php" style="color:red"><span class="glyphicon glyphicon-plus-sign"></span> <font color="#FFFF00">商</font><font color="#BFFF00">品</font><font color="#7FFF00">列</font><font color="#3FFF00">表</font></a>
          </li>
            <li class="">
                 <a href="kmlist.php" style="color:red"><span class="glyphicon glyphicon-plus-sign"></span> <font color="#8000FF">卡</font><font color="#4040FF">密</font><font color="#0080FF">列</font><font color="#00C0FF">表</font></a>
             </li>
            </ul>
		  <li class="">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:#f40086;"><span class="glyphicon glyphicon-list-alt"></span> <font color="#8000FF">发</font><font color="#4040BF">卡</font><font color="#00807F">系</font><font color="#00C03F">统</font><b class="caret"></b></a>
            <ul class="dropdown-menu">
            <li class="">
            <a href="./fakalist.php" style="color:blue"><span class="glyphicon glyphicon-globe"></span> <font color="#8000FF">库</font><font color="#4040BF">存</font><font color="#00807F">列</font><font color="#00C03F">表</font></a>
            </li>
			  <li class="">
                 <a href="./fakakms.php?my=add" style="color:blue"><span class="glyphicon glyphicon-plus-sign"></span> <font color="#8000FF">添</font><font color="#4040BF">加</font><font color="#00807F">卡</font><font color="#00C03F">密</font></a>
             </li>
            </ul>
		  
		  <li class="">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:#0071ce;"><span class="glyphicon glyphicon-cog"></span> <font color="#FF00FF">分</font><font color="#BF00FF">站</font><font color="#8000FF">管</font><font color="#8000FF">理</font><b class="caret"></b></a>
            <ul class="dropdown-menu">
              
               <li><a href="./sitelist.php" style="color:gold"><font color="#FF00FF">分</font><font color="#BF00FF">站</font><font color="#8000FF">列</font><font color="#8000FF">表</font></a></li>
               <li><a href="./sitelist.php?my=add" style="color:gold"><font color="#FF00FF">添</font><font color="#BF00FF">加</font><font color="#8000FF">分</font><font color="#8000FF">站</font></a><li>
               <li><a href="./tixian.php" style="color:gold"><font color="#FF00FF">余</font><font color="#BF00FF">额</font><font color="#8000FF">提</font><font color="#8000FF">现</font></a></li>
               <li><a href="./record.php" style="color:gold"><font color="#FF00FF">收</font><font color="#BF00FF">支</font><font color="#8000FF">明</font><font color="#8000FF">细</font></a></li>
               <li><a href="./sitelist.php?power=0" style="color:gold"><font color="#FF00FF">普</font><font color="#DB00FF">及</font><font color="#B700FF">版</font><font color="#9300FF">分</font><font color="#8000FF">站</font><font color="#8000FF">管</font><font color="#8000FF">理</font></a><li>
               <li><a href="./sitelist.php?power=1" style="color:gold"><font color="#FF00FF">专</font><font color="#DB00FF">业</font><font color="#B700FF">版</font><font color="#9300FF">分</font><font color="#8000FF">站</font><font color="#8000FF">管</font><font color="#8000FF">理</font></a><li>
               <li><a href="./set.php?mod=fenzhan" style="color:gold"><font color="#FF00FF">分</font><font color="#D500FF">站</font><font color="#AB00FF">全</font><font color="#8100FF">局</font><font color="#8000FF">设</font><font color="#8000FF">置</font></a><li>
          <?php if($conf['fenzhan_tixian']==1){?><li><a href="./tixian.php" style="color:gold"><font color="#FF00FF">站</font><font color="#D500FF">长</font><font color="#AB00FF">收</font><font color="#8100FF">入</font><font color="#8000FF">提</font><font color="#8000FF">现</font></a><li><?php }?>
            </ul>
            </li>
           <li class="<?php echo checkIfActive('choujiang,set')?>">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:#0071ce;"><span class="glyphicon glyphicon-cog"></span> <font color="#FF00FF">特</font><font color="#BF00FF">色</font><font color="#8000FF">工</font><font color="#8000FF">具</font><b class="caret"></b></a>
         <ul class="dropdown-menu">
			  <li><a href="./md5.php"> <font color="#FF00FF">m</font><font color="#BF00FF">d</font><font color="#8000FF">5</font><font color="#8000FF">加密</font></a><li>
			  <li><a href="./base64.php"> <font color="#FF00FF">b</font><font color="#BF00FF">a</font><font color="#8000FF">s</font><font color="#8000FF">e64</font></a><li>
			  <li><a href="http://ddidc.top"> <font color="#FF00FF">小</font><font color="#BF00FF">黑</font><font color="#8000FF">互</font><font color="#8000FF">联</font></a><li>
    </ul>
         </li>
          <li class="">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:#0071ab;"><span class="glyphicon glyphicon-cog"></span> <font color="#FF60FF">系</font><font color="#BF20FF">统</font><font color="#8000FF">设</font><font color="#8000FF">置</font><b class="caret"></b></a>
            <ul class="dropdown-menu">
              
               <li><a href="./set.php?mod=site" style="color:silver"><font color="#FF80FF">主</font><font color="#D556D5">站</font><font color="#AB2CC0">信</font><font color="#8102C0">息</font><font color="#5700C0">管</font><font color="#2D00C0">理</font></a></li>
               <li><a href="./set.php?mod=gonggao" style="color:silver"><font color="#FF80FF">主</font><font color="#D556D5">站</font><font color="#AB2CC0">公</font><font color="#8102C0">告</font><font color="#5700C0">管</font><font color="#2D00C0">理</font></a></li>
               <li><a href="./gonggao.php" style="color:silver"><font color="#FF80FF">弹</font><font color="#D556D5">窗</font><font color="#AB2CC0">公</font><font color="#8102C0">告</font><font color="#5700C0">管</font><font color="#2D00C0">理</font></a></li>
               <li><a href="./pricejk.php" style="color:silver"><font color="#FF80FF">社</font><font color="#D556D5">区</font><font color="#AB2CC0">价</font><font color="#8102C0">格</font><font color="#5700C0">监</font><font color="#2D00C0">控</font></a></li>
               <li><a href="./clean.php" style="color:silver"><font color="#FF80FF">系</font><font color="#D556D5">统</font><font color="#AB2CC0">数</font><font color="#8102C0">据</font><font color="#5700C0">清</font><font color="#2D00C0">理</font></a></li>
               <li><a href="./shequlist.php" style="color:silver"><font color="#FF80FF">社</font><font color="#D556D5">区</font><font color="#AB2CC0">对</font><font color="#8102C0">接</font><font color="#5700C0">管</font><font color="#2D00C0">理</font></a></li>
               <li><a href="./set.php?mod=mail" style="color:silver"><font color="#FF80FF">邮</font><font color="#D556D5">箱</font><font color="#AB2CC0">接</font><font color="#8102C0">口</font><font color="#5700C0">配</font><font color="#2D00C0">置</font></a></li>
               <li><a href="./set.php?mod=pay" style="color:silver"><font color="#FF80FF">支</font><font color="#D556D5">付</font><font color="#AB2CC0">接</font><font color="#8102C0">口</font><font color="#5700C0">配</font><font color="#2D00C0">置</font></a></li>
               <li><a href="./set.php?mod=template" style="color:silver"><font color="#FF80FF">首</font><font color="#D556D5">页</font><font color="#AB2CC0">模</font><font color="#8102C0">版</font><font color="#5700C0">设</font><font color="#2D00C0">置</font></a></li>
               <li><a href="./set.php?mod=upimg" style="color:silver"><font color="#FF80FF">网</font><font color="#DF60DF">站</font><font color="#BF40C0">l</font><font color="#9F20C0">o</font><font color="#7F00C0">g</font><font color="#5F00C0">o</font><font color="#3F00C0">管</font><font color="#1F00C0">理</font></a><li>
               <li><a href="./youyun.php" style="color:silver"><font color="#FF80FF">网</font><font color="#D556D5">站</font><font color="#AB2CC0">前</font><font color="#8102C0">台</font><font color="#5700C0">设</font><font color="#2D00C0">置</font></a></li>
               <li><a href="./choujiang.php" style="color:silver"><font color="#FF80FF">抽</font><font color="#D556D5">奖</font><font color="#AB2CC0">配</font><font color="#8102C0">置</font></a></li>
               <li><a href="./update.php" style="color:silver"><font color="#FF80FF">检</font><font color="#D556D5">查</font><font color="#AB2CC0">更</font><font color="#8102C0">新</font></a></li>
            </ul>
          </li>
        
          <li><a href="./login.php?act=out" style="color:#18ce6a;"><span class="glyphicon glyphicon-log-out"></span> <font color="#8000FF">退</font><font color="#8000FF">出</font><font color="#8000FF">登</font><font color="#8000FF">录</font></a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
<?php 
}else{
    exit("<script language='javascript'>window.location.href='./login.php';</script>");
}  
?>