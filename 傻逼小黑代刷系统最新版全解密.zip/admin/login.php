<?php
/**
 * 登录
**/
$is_defend=true;
include("../includes/common.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$code=daddslashes($_POST['code']);
	if (!$code || ($code != $_SESSION['vc_code'])) {
		unset($_SESSION['vc_code']);
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('验证码错误！');history.go(-1);</script>");
	}elseif($user==$conf['admin_user'] && $pass==$conf['admin_pwd']) {
		unset($_SESSION['vc_code']);
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("admin_token", $token, time() + 604800);
		saveSetting('adminlogin',$date);
		log_result('后台登录', 'IP:'.$clientip, null, 1);
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登陆管理中心成功！');window.location.href='./';</script>");
	}else {
		unset($_SESSION['vc_code']);
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('不知道密码登你妈逼啊！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("admin_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
?>
  
<html lang="zh-CN"><head>
<meta charset="utf-8">
        <meta charset="utf-8">
        <title>后台登陆 |  <?php echo $conf['sitename']?></title>
        <meta name="description" content="OneUI - Admin Dashboard Template & UI Framework">
        <meta name="author" content="pixelcave">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=11.0" id="mixia_vpid">
        <link rel="shortcut icon" href="https://www.08cp.cn/assets/img/favicons/favicon.png">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">
        <link rel="stylesheet" href="https://www.08cp.cn/skin/css/slick.min.css">
        <link rel="stylesheet" href="https://www.08cp.cn/skin/css/slick-theme.min.css">
        <link rel="stylesheet" id="css-main" href="https://www.08cp.cn/skin/css/oneui.css">	
<link rel="stylesheet" href="https://www.08cp.cn/assets/layer/skin/default/layer.css?v=3.0.3303" id="layuicss-skinlayercss"></head>
<body>
	<br>
	<div class="col-lg-8 col-md-12 col-lg-offset-2 text-center">
<div class="panel panel-info">
<div class="panel-heading font-bold">后台管理登陆</div>
			<img class="img-circle m-b-xs" style="border: 2px solid yellow; margin-left:3px; margin-right:3px;" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'];?>&spec=100" width="84px" height="84px" alt="<?php echo $conf['sitename']?>">
            <li class="list-group-item"><center>
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block animated zoomIn" style="float: none;">
			<form name="form" method="post" action="login.php">
                            <div class="block block-themed block-rounded">
                                <div class="block-header bg-primary-light">
                                    <h3 class="block-title">请输入您的后台信息</h3>
                                </div>
		<div class="panel-body">

<div class="text-danger wrapper text-center" ng-show="authError">
</div>
				<div class="form-group">
					<label for="exampleInputEmail1">用户账号</label>

<input type="text" name="user" placeholder="用户账号" value="<?php echo @$_GET['user']?>" class="form-control no-border" required>
</div>
				<div class="form-group">
					<label for="exampleInputEmail1">用户密码</label>

<input type="password" name="pass" placeholder="用户密码" value="<?php echo @$_GET['pass']?>" class="form-control no-border" required>
</div>
<div class="input-group">
				<span class="input-group-addon"><span class="glyphicon glyphicon-adjust"></span></span>
				<input type="number" class="form-control" name="code" placeholder="输入验证码" autocomplete="off" required>
				<span class="input-group-addon" style="padding: 0">
					<img src="./code.php?r=<?php echo time();?>"height="32"onclick="this.src='./code.php?r='+Math.random();" title="点击更换验证码">
				</span>
			</div><br/>
<button type="submit" class="btn btn-block btn-primary" ng-click="login()" ng-disabled="form.$invalid">立即登录</button

</div>
		
</div></form>
<div class="text-center">
<p>
<small class="text-muted"> <?php echo $conf['sitename']?><br>© 小黑代刷系统  |2015~2020</small>
</p>
</div>
</div>

<script src="https://template.down.swap.wang/ui/angulr_2.0.1/bower_components/jquery/dist/jquery.min.js"></script>
<script src="https://template.down.swap.wang/ui/angulr_2.0.1/bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="//cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://www.08cp.cn/user/assets/layer/layer.js"></script>
<script src="//static.geetest.com/static/tools/gt.js"></script>

</body></html>