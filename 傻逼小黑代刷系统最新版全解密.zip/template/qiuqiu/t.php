<?php
if(!defined('IN_CRONLITE'))exit();
echo $conf['modal'];
?>