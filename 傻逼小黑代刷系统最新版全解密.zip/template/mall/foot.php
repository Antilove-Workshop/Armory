
<script>!window.jQuery && document.write("<script src=\"//lib.baomitu.com/jquery/1.12.4/jquery.min.js\">"+"</scr"+"ipt>");</script>


<script type="text/javascript" src="<?php echo $cdnserver?>assets/mall/js/index.js?t=10"></script>

      <!--  bottom-bottom-->
<style>

</style>
<div style="width:100%;background:#000000;">
   <div class="foot" style="width:1200px;background:#000000;">
       <div class="foot_con" style="padding-top:32px;">
        
		 <font color='#fff'>本站由 <a href="./" target="_blank" title="<?php echo $conf['sitename']?>"><?php echo $conf['sitename']?></a> 独立运营<br /><br />
			联系QQ： <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" target="_blank" title="<?php echo $conf['kfqq']?>"><?php echo $conf['kfqq']?> </a> <br /><br />
		 </font>
												

      	<div class="clear"></div>
      
      </div>

	 </div>
<div class="FootCopy">
	<div class="FootCopyBox">
	&copy; Powered by <a href="./"><?php echo $conf['sitename']?></a>
	</div>
</div>