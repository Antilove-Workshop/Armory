<?php
if(!defined('IN_CRONLITE'))exit();
include("../includes/common.php");
?>
<div style=" text-align:center; color:#000; font-weight:bold; background:#208AD4; padding:5px 0px; color:#fff; margin-left:-15px; margin-top:-10px;">平台站点公告</div>
<?php echo $conf['anounce']?>