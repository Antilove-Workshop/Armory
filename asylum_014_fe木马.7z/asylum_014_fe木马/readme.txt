Asylum 0.1.4 (Fearless Edition)
12/2/2001

<< Readme: >>

I modified the Asylum 0.1.3 Client, EditServer and Server in hopes of updating Asylum a little bit since it is an awesome backdoor (I know a lot of people will agree with me)!  I did NOT, I repeat NOT code the original Asylum.  In fact, I didn't code Asylum 0.1.4 (Fearless Edition), I redid the GUI, moved some code around, added some, deleted some and modified code in the Client, EditServer and Server.  Slim is the programmer who writes the Asylum series.  He released the sourcecode, this is the ONLY reason Asylum 0.1.4 (Fearless Edition) was made possible.  If he kept the source to himself, you probably would not be reading this.  Thanks slim, you own :)


<< Known Bugs: >>

* Problem: ICQ Pager not working
* Fix: There is a limit of 194 characters for the ICQ pager.  The server uses ~113 characters automatically.  It then adds in the victims username, windows version and the description you wrote in the editserver.  so keep that in mind, keep your password, port, description fairly short because you have less than ~81 chars to work with.  If you don't get the ICQ page, this is probably the problem.  As soon as there is a way to bypass this limit, you can bet i'll release another version.

<< Greetz & Thanks to: >>

Slim .............................. for an AWESOME backdoor
Its_ON ............................ sup foo, 901C 4 Life
Murder4Hire ....................... hello "carl"
Ghirai ............................ general relations/vb coding
Gobo .............................. general relations/vb coding
Everyone @ Evil Eye Software ...... general relations/delphi coding
tt ................................ general relations/delphi coding
Nilez ............................. general relations/delphi coding
detro & illwill ................... general relations/webspace
all fearless fans ................. general relations

sorry if i forgot you in the greetz

<< Contact: >>

Why don't you join the official fearless IRC channel?

IRC: #fearless on irc.sub7.org
Web: http://areyoufearless.com
E-Mail: mf4@flashmail.com

<< Extra >>
Listening to "Blaze - Grave Ain't No Place" at the time of release :)