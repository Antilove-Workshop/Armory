<div data-page="data" class="page">
    <div class="navbar">
        <div class="navbar-inner">
            <div class="left">
                <a href="index.html" class="back link icon-only">
                    <i class="icon icon-back"></i>
                </a>
            </div>
            <div>历史Token记录</div>
            <div class="right">
                <a href="qid://refresh" class="back link icon-only">
                    <i class="icon icon-refresh">刷新Token记录</i>
                </a>
            </div>
          </div>
    </div>
    <div class="page-content ">
        <div class="list-block media-list">
            <ul>

<?php
date_default_timezone_set('Asia/Shanghai');//设置时区

$imei=isset($_GET['imei'])?$_GET['imei']:false;//获取IMEI码

if($imei && file_exists(dirname(__FILE__).'/white-list/'.$imei)){
$i = 0;
$data=explode("\n",file_get_contents(dirname(__FILE__).'/white-list/'.$imei));
array_pop($data);
rsort($data);
foreach($data as $value){?>
<?php $t=explode('=',$data[$i]);?>
                <li class="swipeout">
                    <div class="swipeout-content">
                        <a id="copy" class="item-link item-content" data-clipboard-text="<?php echo $t['1']; ?>">
                            <div class="item-inner">
                                <div class="item-title-row">
                                    <div class="item-title"><b><?php echo $t['1']; ?></b></div>

                                </div>
                                <div class="item-subtitle">
                                    <div class="chip bg-green" onclick="myApp.alert('<?php echo date('Y-m-d H:i:s',$t['0']); ?>', '生成时间');">
                                        <div class="chip-label"><?php echo date('Y-m-d H:i:s',$t['0']); ?></div>
                                    </div>
                            </div>
                            </div>
                        </a>
                    </div>
                </li>
<?php
    $i++; }}else{ ?>
                    <li class="swipeout">
                    <div class="swipeout-content">
                        <a href="javascript:void(0);" class="item-link item-content">
                            <div class="item-inner">
                                <div class="item-title-row">
                                    <div class="item-title">404 Not Found</div>

                                </div>
                                <div class="item-subtitle">不存在的，来源有误或者你是用的不是最新版 QQIP探测，请下载/更新 QQIP探测(黑镰论坛版)</div>
                            </div>
                        </a>
                    </div>
                </li>
<?php } ?>
            </ul>
        </div>
    </div>
</div>