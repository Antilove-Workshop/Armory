<?php
date_default_timezone_set('Asia/Shanghai');//设置时区

$imei=isset($_GET['imei'])?$_GET['imei']:false;//获取IMEI码
$token=isset($_GET['token'])?$_GET['token']:false;//获取token

if($imei){
  //传入了IMEI码

  if(file_exists(dirname(__FILE__).'/white-list/'.$imei)){// dirname(__FILE__) 这个是获取当前文件下的绝对路径
    //IMEI码存在
    if(file_put_contents(dirname(__FILE__).'/'.$imei,time().'='.$token."\n",FILE_APPEND)){
      //echo '存入token成功';
    }else{
      //echo '存入token失败';
    }
  }else{
    //IMEI码不存在
  }

}