# coding: utf-8

__title__ = 'scrapydweb'
__version__ = '1.4.0'
__author__ = 'my8100'
__author_email__ = 'my8100@gmail.com'
__url__ = 'https://github.com/my8100/scrapydweb'
__license__ = 'GNU General Public License v3.0'
__description__ = ("Web app for Scrapyd cluster management, "
                   "with support for Scrapy log analysis & visualization.")
