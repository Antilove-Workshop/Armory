<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name='referrer' content="never">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<!--[if lt IE 9]>
<script src="<?php echo $mkcms_domain;?>style/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="<?php echo $mkcms_domain;?>style/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="<?php echo $mkcms_domain;?>style/css/bootstrap.min.css" rel="stylesheet" type="text/css" />				
<link href="<?php echo $mkcms_domain;?>style/css/swiper.min.css" rel="stylesheet" type="text/css" >		
<link href="<?php echo $mkcms_domain;?>style/font/iconfont.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $mkcms_domain;?>style/css/blackcolor.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $mkcms_domain;?>style/css/style.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $mkcms_domain;?>style/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>style/js/bootstrap.min.js"></script>		
<script src="<?php echo $mkcms_domain;?>style/js/function.js"></script>
<script type='text/javascript' src="<?php echo $mkcms_domain;?>style/js/LazyLoad.js"></script>
<script type='text/javascript' src="<?php echo $mkcms_domain;?>style/js/swiper.min.js"></script>
<script type="text/javascript " src="<?php echo $mkcms_domain;?>style/js/history.js "></script>	
<style type="text/css">
body{background-color: #28162c; color: #ccc;}
body:before{ content: ""; position: fixed; z-index: -1000; top: 0; left: 0; right: 0; bottom: 0;background: url(<?php echo $mkcms_beijing;?>) center 0 no-repeat;background-size: cover;}
@media (max-width: 767px){
    body:before{background: url() center 0 no-repeat; background-attachment: fixed;background-size: cover;} 
}
</style>


