<?php include('system/inc.php');
include 'system/list.php';
$page=$_GET['page'];
include('moban/'.$mkcms_bdyun.'/zongyi.php');?>