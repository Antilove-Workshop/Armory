<?php include('system/inc.php');
include('moban/'.$mkcms_bdyun.'/vlist.php');?>